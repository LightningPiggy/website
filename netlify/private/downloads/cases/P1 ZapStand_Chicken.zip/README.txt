ZapStand Chicken, version 1
===========================

P1 ZapStand_Chicken.3mf holds every piece of the stand, turned the way it prints and lying side by side,
each in its colour. Open it in your slicer; the pieces may need arranging onto your printer's
plate (most slicers have an Arrange button) and there may be more than fit on one plate.

PIECES

  Piece                    How many  Colour                    Size (mm)           Layers
  Body                     1         cream #F4F1E8             96 x 67 x 70        0.16 mm
  Head, front              1         cream #F4F1E8             72 x 53 x 33        0.1 mm
  Head, back               1         cream #F4F1E8             72 x 54 x 23        0.1 mm
  Head pin                 3         cream #F4F1E8             3 x 3 x 8           0.16 mm
  Tail feather, left       1         cream #F4F1E8             23 x 10 x 4         0.16 mm
  Tail feather, middle     1         cream #F4F1E8             24 x 11 x 4         0.16 mm
  Tail feather, right      1         cream #F4F1E8             23 x 10 x 4         0.16 mm
  Eye shine                2         cream #F4F1E8             3 x 3 x 2           0.16 mm
  Eye shine, spare         2         cream #F4F1E8             3 x 3 x 2           0.16 mm
  Cheek, left              1         red #E0453A               10 x 7 x 2          0.16 mm
  Cheek, right             1         red #E0453A               10 x 7 x 2          0.16 mm
  Wattle                   1         red #E0453A               6 x 10 x 4          0.16 mm
  Comb, 1 (front to back)  1         red #E0453A               16 x 9 x 4          0.16 mm
  Comb, 2 (front to back)  1         red #E0453A               19 x 10 x 4         0.16 mm
  Comb, 3 (front to back)  1         red #E0453A               17 x 9 x 4          0.16 mm
  Eye, left                1         black #1A1A1A             9 x 10 x 5          0.16 mm
  Eye, right               1         black #1A1A1A             9 x 10 x 5          0.16 mm
  Beak                     1         orange #F5A623            14 x 10 x 11        0.16 mm
  Foot, front left         1         orange #F5A623            17 x 28 x 4         0.16 mm
  Foot, front right        1         orange #F5A623            17 x 28 x 4         0.16 mm
  Foot, back left          1         cream #F4F1E8             17 x 17 x 4         0.16 mm
  Foot, back right         1         cream #F4F1E8             17 x 17 x 4         0.16 mm
  Button                   2         cream #F4F1E8             6 x 6 x 6           0.16 mm

  28 pieces in all.

COLOURS

  cream #F4F1E8                     17 pieces
  red #E0453A                       6 pieces
  black #1A1A1A                     2 pieces
  orange #F5A623                    3 pieces

  These are the colours the ZapStand Badge Maker shows the stand in. Any others will do just
  as well, and close shades can share one filament.

  Every piece is a single colour, so no multi-colour printer is needed: print each piece in its
  colour, or the whole stand in one colour and the details in others.

PRINT SETTINGS THE DESIGNER USED

  Material      matte PLA
  Nozzle        0.4 mm
  Layers        0.16 mm; the pieces marked finer above at their own height
  First layer   0.2 mm
  Walls         3
  Infill        15% grid
  Supports      none
  Brim          none

BEFORE YOU PRINT

  - The pieces are already turned the way they print, flat sides down, so they need no
    supports. Keep them that way.
  - The biggest piece is 96 x 67 x 70 mm: check it fits your printer.
  - Pieces marked 0.1 mm under Layers were printed with finer layers for a smoother surface.
    Give them their own layer height in your slicer, or print them in a separate run.
  - Pieces that fit together are drawn with small clearances, and the designer printed them
    with hole and first-layer (elephant's foot) compensation off. If your printer prints holes
    small or squashes the first layer outwards, print one small piece that fits into another
    first, to check.
  - The badge slot is 50.4 x 12.4 mm, 3.6 mm deep. ZapStand badges are 50.2 x 12.2 mm and 3.6
    mm thick, so they sit flush; make one with the ZapStand Badge Maker.
  - The stand holds a ZapBox: the Waveshare ESP32-S3 board and its parts are not included.
  - The ZapBox is held from behind by four hex socket screws, through the round holes in the
    stand's back. Turn them with a hex (Allen) key whose long arm reaches 35 mm into the holes.
  - The legs reach the table and the feet are rings round them. To fit one, stand the ring on
    the table, its lines (toes, a hoof's cleft) turned to meet the leg's, set the stand on it
    and press down until the ring is flush with the leg's end. Small ribs inside the ring grip
    the leg: no glue is needed.
  - The head's front piece presses onto the block on top of the body and stays on for good:
    with the body standing on the table, push it straight down until it sits on the body. It
    takes firm pressure, as ribs on the block grip it. Then fit the back of the head with the
    head pins.
  - A chicken has two legs: the back feet (Foot, back left and right) are plain round rings in
    the body's colour, without toes. They press on like the front feet.

BADGES

  The files named P1 ZapStand_Badge_<name> are badges for the stand's slot, 50.2 x 12.2 mm,
  made with the ZapStand Badge Maker: your own, or the SATOSHI and Lightning Piggy badges if
  you didn't make one.

  - A badge as a plain 3MF is one piece with each colour as a part of its own, named with its
    filament number and colour. Pick the filament for each part in your slicer and print with
    0.2 mm layers (the first layer 0.2 mm too), so the colours change between layers.
  - A badge made for your printer is a slicer project with its filaments and settings set:
    check them in your slicer, then slice and print.
  - A badge made for any printer as STL files comes as one file per colour, all on the same
    origin: load them together as one object.

LICENCE

  The ZapStand Chicken is by its designer, credited on https://lightningpiggy.com/build/cases/,
  and shared under CC BY-SA 4.0: https://creativecommons.org/licenses/by-sa/4.0/

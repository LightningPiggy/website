ZapStand Classic, version 1
===========================

P1 ZapStand_Classic.3mf holds every piece of the stand, turned the way it prints and lying side by side,
each in its colour. Open it in your slicer; the pieces may need arranging onto your printer's
plate (most slicers have an Arrange button) and there may be more than fit on one plate.

PIECES

  Piece   How many  Colour                    Size (mm)           Layers
  Stand   1         black #1A1A1A             61 x 48 x 57        0.2 mm
  Button  2         black #1A1A1A             6 x 6 x 6           0.2 mm

  3 pieces in all.

COLOURS

  black #1A1A1A                     3 pieces

  These are the colours the ZapStand Badge Maker shows the stand in. Any others will do just
  as well, and close shades can share one filament.

  Every piece is a single colour, so no multi-colour printer is needed: print each piece in its
  colour, or the whole stand in one colour and the details in others.

PRINT SETTINGS THE DESIGNER USED

  Material      matte PLA
  Nozzle        0.4 mm
  Layers        0.2 mm
  First layer   0.2 mm
  Walls         2
  Infill        15% grid
  Supports      none
  Brim          automatic (the slicer adds one where a piece needs it)

BEFORE YOU PRINT

  - The pieces are already turned the way they print, flat sides down, so they need no
    supports. Keep them that way.
  - The biggest piece is 61 x 48 x 57 mm: check it fits your printer.
  - Pieces that fit together are drawn with small clearances, and the designer printed them
    with hole and first-layer (elephant's foot) compensation off. If your printer prints holes
    small or squashes the first layer outwards, print one small piece that fits into another
    first, to check.
  - The badge slot is 50.4 x 12.4 mm, 3.6 mm deep. ZapStand badges are 50.2 x 12.2 mm and 3.6
    mm thick, so they sit flush; make one with the ZapStand Badge Maker.
  - The stand holds a ZapBox: the Waveshare ESP32-S3 board and its parts are not included.

BADGES

  The files named P1 ZapStand_Badge_<name> are badges for the stand's slot, 50.2 x 12.2 mm,
  made with the ZapStand Badge Maker: your own, or the SATOSHI and Lightning Piggy badges if
  you didn't make one.

  - A badge as a plain 3MF is one piece with each colour as a part of its own, named with its
    filament number and colour. Pick the filament for each part in your slicer and print with
    0.2 mm layers (the first layer 0.2 mm too), so the colours change between layers.
  - A badge made for your printer is a slicer project with its filaments and settings set:
    check them in your slicer, then slice and print.
  - A badge made for any printer as STL files comes as one file per colour, all on the same
    origin: load them together as one object.

LICENCE

  The ZapStand Classic is by its designer, credited on https://lightningpiggy.com/build/cases/,
  and shared under CC BY-SA 4.0: https://creativecommons.org/licenses/by-sa/4.0/

ZapStand Piggy, version 1
=========================

P1 ZapStand_Piggy.3mf holds every piece of the stand, turned the way it prints and lying side by side,
each in its colour. Open it in your slicer; the pieces may need arranging onto your printer's
plate (most slicers have an Arrange button) and there may be more than fit on one plate.

PIECES

  Piece              How many  Colour                    Size (mm)           Layers
  Body               1         light pink #F4A6B8        96 x 67 x 70        0.16 mm
  Head, front        1         light pink #F4A6B8        76 x 52 x 34        0.1 mm
  Head, back         1         light pink #F4A6B8        75 x 53 x 22        0.1 mm
  Ear, left          1         light pink #F4A6B8        21 x 27 x 6         0.16 mm
  Ear, right         1         light pink #F4A6B8        21 x 27 x 6         0.16 mm
  Head pin           3         light pink #F4A6B8        3 x 3 x 8           0.16 mm
  Tail               1         light pink #F4A6B8        20 x 12 x 5         0.16 mm
  Cheek, left        1         soft pink #E8708F         11 x 7 x 2          0.16 mm
  Cheek, right       1         soft pink #E8708F         11 x 7 x 2          0.16 mm
  Nostril, left      1         deep pink #B83A5E         4 x 6 x 2           0.16 mm
  Nostril, right     1         deep pink #B83A5E         4 x 6 x 2           0.16 mm
  Inner ear, left    1         pink #D9547A              15 x 17 x 4         0.16 mm
  Inner ear, right   1         pink #D9547A              15 x 17 x 4         0.16 mm
  Hoof, front left   1         pink #D9547A              17 x 17 x 4         0.16 mm
  Hoof, front right  1         pink #D9547A              17 x 17 x 4         0.16 mm
  Hoof, back left    1         pink #D9547A              17 x 17 x 4         0.16 mm
  Hoof, back right   1         pink #D9547A              17 x 17 x 4         0.16 mm
  Eye, left          1         black #1A1A1A             9 x 10 x 5          0.16 mm
  Eye, right         1         black #1A1A1A             9 x 10 x 5          0.16 mm
  Eye shine          2         white #FFFFFF             3 x 3 x 2           0.16 mm
  Eye shine, spare   2         white #FFFFFF             3 x 3 x 2           0.16 mm
  Button             2         light pink #F4A6B8        6 x 6 x 6           0.16 mm

  27 pieces in all.

COLOURS

  light pink #F4A6B8                11 pieces
  pink #D9547A                      6 pieces
  soft pink #E8708F                 2 pieces
  deep pink #B83A5E                 2 pieces
  black #1A1A1A                     2 pieces
  white #FFFFFF                     4 pieces

  These are the colours the ZapStand Badge Maker shows the stand in. Any others will do just
  as well, and close shades can share one filament.

  Every piece is a single colour, so no multi-colour printer is needed: print each piece in its
  colour, or the whole stand in one colour and the details in others.

PRINT SETTINGS THE DESIGNER USED

  Material      matte PLA
  Nozzle        0.4 mm
  Layers        0.16 mm; the pieces marked finer above at their own height
  First layer   0.2 mm
  Walls         3
  Infill        15% grid
  Supports      none
  Brim          none

BEFORE YOU PRINT

  - The pieces are already turned the way they print, flat sides down, so they need no
    supports. Keep them that way.
  - The biggest piece is 96 x 67 x 70 mm: check it fits your printer.
  - Pieces marked 0.1 mm under Layers were printed with finer layers for a smoother surface.
    Give them their own layer height in your slicer, or print them in a separate run.
  - Pieces that fit together are drawn with small clearances, and the designer printed them
    with hole and first-layer (elephant's foot) compensation off. If your printer prints holes
    small or squashes the first layer outwards, print one small piece that fits into another
    first, to check.
  - The badge slot is 50.4 x 12.4 mm, 3.6 mm deep. ZapStand badges are 50.2 x 12.2 mm and 3.6
    mm thick, so they sit flush; make one with the ZapStand Badge Maker.
  - The stand holds a ZapBox: the Waveshare ESP32-S3 board and its parts are not included.
  - The ZapBox is held from behind by four hex socket screws, through the round holes in the
    stand's back. Turn them with a hex (Allen) key whose long arm reaches 35 mm into the holes.
  - The legs reach the table and the feet are rings round them. To fit one, stand the ring on
    the table, its lines (toes, a hoof's cleft) turned to meet the leg's, set the stand on it
    and press down until the ring is flush with the leg's end. Small ribs inside the ring grip
    the leg: no glue is needed.
  - The head's front piece presses onto the block on top of the body and stays on for good:
    with the body standing on the table, push it straight down until it sits on the body. It
    takes firm pressure, as ribs on the block grip it. Then fit the back of the head with the
    head pins.

BADGES

  The files named P1 ZapStand_Badge_<name> are badges for the stand's slot, 50.2 x 12.2 mm,
  made with the ZapStand Badge Maker: your own, or the SATOSHI and Lightning Piggy badges if
  you didn't make one.

  - A badge as a plain 3MF is one piece with each colour as a part of its own, named with its
    filament number and colour. Pick the filament for each part in your slicer and print with
    0.2 mm layers (the first layer 0.2 mm too), so the colours change between layers.
  - A badge made for your printer is a slicer project with its filaments and settings set:
    check them in your slicer, then slice and print.
  - A badge made for any printer as STL files comes as one file per colour, all on the same
    origin: load them together as one object.

LICENCE

  The ZapStand Piggy is by its designer, credited on https://lightningpiggy.com/build/cases/,
  and shared under CC BY-SA 4.0: https://creativecommons.org/licenses/by-sa/4.0/
